<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/dashboard.css')); ?>">
</head>
<body>
    <div class="header">
        <form action="<?php echo e(route('admin.logout')); ?>" method="POST" id="logout-form" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>

        <img src="<?php echo e(asset('images/logout.png')); ?>" alt="Logout" class="logout" onclick="document.getElementById('logout-form').submit();">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" class="logo">
    </div>

    <div class="dashboard">
        <div class="grid-container">
            <a href="<?php echo e(route('qrcode')); ?>" class="card">
                <div class="card-header">QR CODE ABSENSI</div>
                <div class="card-content">
                    <div class="image-container">
                        <div class="background-box"></div>
                        <img src="<?php echo e(asset('images/qr_code.png')); ?>" alt="QR Code">
                    </div>
                </div>
            </a>
            <a href="<?php echo e(route('admin.laporan')); ?>" class="card">
                <div class="card-header">LAPORAN ABSENSI</div>
                <div class="card-content">
                    <img src="<?php echo e(asset('images/laporan_absensi.png')); ?>" alt="Laporan Absensi">
                </div>
            </a>
            <a href="<?php echo e(route('data_admin')); ?>" class="card">
                <div class="card-header">DATA PEGAWAI</div>
                <div class="card-content">
                    <div class="image-container">
                        <div class="background-box"></div>
                        <img src="<?php echo e(asset('images/data_pegawai.png')); ?>" alt="Data Pegawai">
                    </div>
                </div>
            </a>
        </div>
    </div>

    <script>
            <?php if(session('console_log')): ?>
        console.log("<?php echo e(session('console_log')); ?>");
    <?php endif; ?>
    </script>
</body>
</html>
<?php /**PATH D:\SMT6\kp-\kerjapraktik\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>