<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/styleLogin.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
    <div class="logo-box">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" width="300" height="150" style="margin-left: 30px;">
    </div>

    <div class="form-box">
        <h1>LOGIN</h1>
        <div class="line"></div>

        <form action="<?php echo e(route('admin.login.submit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="full_name">Nama Lengkap</label>
            <input type="text" id="full_name" name="full_name" required>

            <label for="password">Password</label>
            <div class="password-container">
                <input type="password" id="password" name="password" required>
                <i id="toggleEye" class="fa-solid fa-eye-slash" onclick="togglePassword()"></i>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="login-btn">LOGIN</button>
        </form>

        <p style="margin-top: 20px; text-align: center;">
            Belum punya akun?
            <a href="<?php echo e(route('admin.register')); ?>" style="text-decoration: underline; color: #007bff;">
                Signup
            </a>
        </p>

        <?php if(session('error')): ?>
            <div style="color: red;"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
    </div>

    <script>
        function togglePassword() {
            let passwordInput = document.getElementById("password");
            let toggleIcon = document.getElementById("toggleEye");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleIcon.classList.remove("fa-eye-slash");
                toggleIcon.classList.add("fa-eye");
            } else {
                passwordInput.type = "password";
                toggleIcon.classList.remove("fa-eye");
                toggleIcon.classList.add("fa-eye-slash");
            }
        }


    <?php if(session('console_log')): ?>
        console.log("<?php echo e(session('console_log')); ?>");
    <?php endif; ?>

    </script>
</body>
</html>
<?php /**PATH D:\SMT6\kp-\kerjapraktik\resources\views/admin/login.blade.php ENDPATH**/ ?>